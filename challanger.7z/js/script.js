var arrayCodificar =[];
function start(){
    console.log('start')

    var buttonCodificador = document.querySelector('#codificador');
    buttonCodificador.addEventListener('click', pegarFraseCodificar);
    console.log(buttonCodificador)


}

function pegarFraseCodificar(){

    var inputCodificar = document.querySelector('#campoTexto');
    var frase = inputCodificar.value;
    console.log(frase);
     var teste = tranformarArray(frase);
    
}

// A letra "e" é convertida para "enter"
// A letra "i" é convertida para "imes"
// A letra "a" é convertida para "ai"
// A letra "o" é convertida para "ober"
// A letra "u" é convertida para "ufat"



function tranformarArray(valor){
    arrayCodificar.push(valor.split());
    console.log(arrayCodificar);
 
}




function codificar(valor){

     if(valor === 'a' || valor === 'A'){
         valor = ai;
     }   
     if(valor === 'e' || valor === 'E'){
         valor = enter;
     }   
     if(valor === 'i' || valor === 'I'){
         valor = imes;
     }   
     if(valor === 'o' || valor === 'O'){
         valor = ober;
     }   
     if(valor === 'u' || valor === 'U'){
         valor = ufat;
     }   
}


 start();